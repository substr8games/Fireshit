# Fireshit 1.1 — Linux x86_64 Binary Bundle

This archive contains the prebuilt Fireshit runtime for **Arch Linux x86_64 running Wayfire 0.10.x**:

- Firemod and `firemodctl`
- FrameTap and its Wayfire plugin
- SUBSTR8 HUD, `wayfire-hudctl`, and the TTY mirror
- Firemod and HUD Wayfire plugins
- runtime metadata, default configuration, btop integration, and systemd units

Fireshit is distributed under the **Fireshit Capture Immunity License 0.1**. See `LICENSE`.

## 1. Install runtime dependencies

```bash
sudo pacman -Syu --needed \
  wayfire wlroots0.19 gtk4 gtk4-layer-shell vte4 \
  ffmpeg libva libdrm wayland pipewire-pulse tmux
```

Optional HUD programs:

```bash
sudo pacman -S --needed btop htop nvtop nethogs iotop
```

OpenSnitch is optional and is not installed by this bundle.

## 2. Install the executables and runtime files

Run these commands from the extracted bundle directory:

```bash
PLUGIN_DIR="/usr/lib/wayfire"
METADATA_DIR="/usr/share/wayfire/metadata"

sudo install -Dm755 bin/* /usr/local/bin/
sudo install -Dm755 plugins/libfiremod-wayfire.so "$PLUGIN_DIR/libfiremod-wayfire.so"
sudo install -Dm755 plugins/libframetap-wayfire.so "$PLUGIN_DIR/libframetap-wayfire.so"
sudo install -Dm755 plugins/libwayfire-hud.so "$PLUGIN_DIR/libwayfire-hud.so"

sudo install -Dm644 metadata/firemod.xml "$METADATA_DIR/firemod.xml"
sudo install -Dm644 metadata/frametap.xml "$METADATA_DIR/frametap.xml"
sudo install -Dm644 metadata/wayfire-hud.xml "$METADATA_DIR/wayfire-hud.xml"

sudo install -Dm644 desktop/org.philabs.Firemod.desktop \
  /usr/local/share/applications/org.philabs.Firemod.desktop
sudo install -Dm644 metainfo/org.philabs.Firemod.metainfo.xml \
  /usr/local/share/metainfo/org.philabs.Firemod.metainfo.xml

sudo install -d /usr/local/share/firemod/modules.d /usr/local/share/firemod/capabilities.d
sudo cp -a firemod/modules.d/. /usr/local/share/firemod/modules.d/
sudo cp -a firemod/capabilities.d/. /usr/local/share/firemod/capabilities.d/

sudo install -Dm644 frametap/frametap.ini.example \
  /usr/local/share/doc/frametap/frametap.ini.example

sudo install -d /usr/local/share/substr8-hud/modules.d /usr/local/share/substr8-hud/btop
sudo install -Dm644 substr8-hud/config.ini /usr/local/share/substr8-hud/config.ini
sudo install -Dm644 substr8-hud/tty.conf /usr/local/share/substr8-hud/tty.conf
sudo install -Dm644 substr8-hud/substr8-hud-console.tmux.conf \
  /usr/local/share/substr8-hud/substr8-hud-console.tmux.conf
sudo cp -a substr8-hud/modules.d/. /usr/local/share/substr8-hud/modules.d/
sudo cp -a substr8-hud/btop/. /usr/local/share/substr8-hud/btop/

sudo install -d /usr/local/libexec/substr8-hud
sudo install -Dm755 libexec/substr8-hud/* /usr/local/libexec/substr8-hud/
sudo install -Dm644 systemd/user/substr8-btop.service \
  /usr/local/lib/systemd/user/substr8-btop.service
sudo install -Dm644 systemd/system/substr8-hud-console@.service \
  /usr/local/lib/systemd/system/substr8-hud-console@.service

sudo install -Dm644 LICENSE /usr/local/share/licenses/fireshit/LICENSE
```

## 3. Seed the per-user HUD configuration

Existing files are preserved.

```bash
HUD_CONFIG="${XDG_CONFIG_HOME:-$HOME/.config}/substr8-hud"
mkdir -p "$HUD_CONFIG/modules.d" "$HUD_CONFIG/btop"
cp -n substr8-hud/config.ini "$HUD_CONFIG/config.ini"
cp -n substr8-hud/tty.conf "$HUD_CONFIG/tty.conf"
cp -n substr8-hud/modules.d/*.ini "$HUD_CONFIG/modules.d/"
cp -n substr8-hud/btop/* "$HUD_CONFIG/btop/"
```

FrameTap’s optional user configuration lives at:

```text
${XDG_CONFIG_HOME:-~/.config}/frametap/config.ini
```

Start from `frametap/frametap.ini.example` when needed.

## 4. Enable the Wayfire plugins

In `~/.config/wayfire.ini`, ensure the `[core]` plugin list contains:

```text
firemod-wayfire frametap-wayfire wayfire-hud
```

Preserve the plugins already present; append these names rather than replacing the list.

Restart Wayfire or log out and back in after installing the plugin shared objects.

Canonical bindings:

- `SUPER` + middle-click: Fireshit utility menu
- `SUPER` + `Home`: cycle SUBSTR8 HUD state

## 5. Enable the compact btop service

Only when `btop` is installed:

```bash
systemctl --user daemon-reload
systemctl --user enable --now substr8-btop.service
```

The physical shared-console service is optional and requires explicit system-level configuration. Do not enable it blindly.

## 6. Verify

```bash
frametap --version
frametap --list
command -v firemod firemodctl frametap wayfire-hud wayfire-hudctl substr8-vt-mirror
wayfire-hudctl status
systemctl --user status substr8-btop.service
```

Check installed library dependencies:

```bash
ldd /usr/local/bin/firemod | grep 'not found' || true
ldd /usr/local/bin/frametap | grep 'not found' || true
ldd /usr/local/bin/wayfire-hud | grep 'not found' || true
ldd "$PLUGIN_DIR/libframetap-wayfire.so" | grep 'not found' || true
```

No output from the `grep 'not found'` checks is the expected result.

## 7. Uninstall

```bash
PLUGIN_DIR="/usr/lib/wayfire"
METADATA_DIR="/usr/share/wayfire/metadata"

systemctl --user disable --now substr8-btop.service 2>/dev/null || true

sudo rm -f \
  /usr/local/bin/firemod /usr/local/bin/firemodctl /usr/local/bin/frametap \
  /usr/local/bin/wayfire-hud /usr/local/bin/wayfire-hudctl \
  /usr/local/bin/substr8-vt-mirror /usr/local/bin/substr8-hud-console \
  /usr/local/bin/substr8-btop /usr/local/bin/substr8-btopctl \
  "$PLUGIN_DIR/libfiremod-wayfire.so" \
  "$PLUGIN_DIR/libframetap-wayfire.so" \
  "$PLUGIN_DIR/libwayfire-hud.so" \
  "$METADATA_DIR/firemod.xml" "$METADATA_DIR/frametap.xml" \
  "$METADATA_DIR/wayfire-hud.xml" \
  /usr/local/share/applications/org.philabs.Firemod.desktop \
  /usr/local/share/metainfo/org.philabs.Firemod.metainfo.xml \
  /usr/local/lib/systemd/user/substr8-btop.service \
  /usr/local/lib/systemd/system/substr8-hud-console@.service

sudo rm -rf \
  /usr/local/share/firemod \
  /usr/local/share/substr8-hud \
  /usr/local/share/doc/frametap \
  /usr/local/libexec/substr8-hud \
  /usr/local/share/licenses/fireshit

systemctl --user daemon-reload
sudo systemctl daemon-reload
```

User configuration under `~/.config/substr8-hud` and `~/.config/frametap` is intentionally preserved.

## Binary provenance

These x86_64 ELF payloads come from the final implementation snapshot supplied with the original repository archive. The implementation source is unchanged in the corrected 1.1 tree except for suite-version/license metadata and FrameTap help text. FrameTap’s embedded public version strings were normalized to `1.1.0`, and debug sections containing local build paths were stripped. For reproducible distro packaging, build the separate Fireshit 1.1 source release on Arch Linux.
